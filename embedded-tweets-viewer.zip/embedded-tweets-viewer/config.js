window.host = "localhost";
window.port = "9200";
